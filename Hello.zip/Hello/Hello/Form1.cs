﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Hello
{
    public partial class Database : Form
    {


        public Database()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection connection = new MySqlConnection(@"Server=127.0.0.1;Database=app_database;Uid=root;");
                MySqlDataAdapter adapter = new MySqlDataAdapter("Showinfo", connection);


                connection.Open();






                DataSet ds = new DataSet();
                adapter.Fill(ds, "Information");
                dataGridView1.DataSource = ds.Tables["Information"];
                connection.Close();
            } catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }




        }

        private void btmSaveInfo_Click(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection(@"Server = 127.0.0.1; Database=save; Uid = root;");
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                MySqlCommand cmd = new MySqlCommand(@"INSERT INTO save1 (Table_No,Item_No,Food_Item,Price,Quantity) VALUES('" + dataGridView1.Rows[i].Cells[0].Value + "','" + dataGridView1.Rows[i].Cells[1].Value + "','" + dataGridView1.Rows[i].Cells[2].Value + "', '" + dataGridView1.Rows[i].Cells[3].Value + "','" + dataGridView1.Rows[i].Cells[4].Value + "')", con);
                MySqlCommand cmd1 = new MySqlCommand(@"INSERT INTO save2 (Table_No,Item_No,Food_Item,Price,Quantity) VALUES('" + dataGridView1.Rows[i].Cells[0].Value + "','" + dataGridView1.Rows[i].Cells[1].Value + "','" + dataGridView1.Rows[i].Cells[2].Value + "', '" + dataGridView1.Rows[i].Cells[3].Value + "','" + dataGridView1.Rows[i].Cells[4].Value + "')", con);
                MySqlCommand cmd2 = new MySqlCommand("eatin", con);
                MySqlCommand cmd3 = new MySqlCommand("takeout", con);


                con.Open();
                cmd.ExecuteNonQuery();
                cmd1.ExecuteNonQuery();
                cmd2.ExecuteNonQuery();
                cmd3.ExecuteNonQuery();
                con.Close();

            }
            MySqlCommand cmd4 = new MySqlCommand("input", con);
            
            con.Open();
            cmd4.ExecuteNonQuery();
           
            con.Close();

            
            
            
            MessageBox.Show("Saved Successfully");






        }

        private void btmNew_Click(object sender, EventArgs e)
        {
           
        }
        
    }
        
        
        
    
}
