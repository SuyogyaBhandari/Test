﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace Project1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            timer1.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection connection = new MySqlConnection(@"Server=127.0.0.1;Database=app_database;Uid=root;");
                MySqlDataAdapter adapter = new MySqlDataAdapter("Showinfo", connection);


                connection.Open();






                DataSet ds = new DataSet();
                adapter.Fill(ds, "Information");
                dataGridView1.DataSource = ds.Tables["Information"];
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }


            MySqlConnection con = new MySqlConnection(@"Server = 127.0.0.1; Database=save; Uid = root;");
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                MySqlCommand cmd = new MySqlCommand(@"INSERT INTO save1 (Table_No,Item_No,Food_Item,Price,Quantity) VALUES('" + dataGridView1.Rows[i].Cells[0].Value + "','" + dataGridView1.Rows[i].Cells[1].Value + "','" + dataGridView1.Rows[i].Cells[2].Value + "', '" + dataGridView1.Rows[i].Cells[3].Value + "','" + dataGridView1.Rows[i].Cells[4].Value + "')", con);
                MySqlCommand cmd1 = new MySqlCommand(@"INSERT INTO save2 (Table_No,Item_No,Food_Item,Price,Quantity) VALUES('" + dataGridView1.Rows[i].Cells[0].Value + "','" + dataGridView1.Rows[i].Cells[1].Value + "','" + dataGridView1.Rows[i].Cells[2].Value + "', '" + dataGridView1.Rows[i].Cells[3].Value + "','" + dataGridView1.Rows[i].Cells[4].Value + "')", con);
                MySqlCommand cmd2 = new MySqlCommand("eatin", con);
                MySqlCommand cmd3 = new MySqlCommand("eatin1", con);
                MySqlCommand cmd4 = new MySqlCommand("takeout", con);
                MySqlCommand cmd5 = new MySqlCommand("takeout1", con);


                con.Open();
                cmd.ExecuteNonQuery();
                cmd1.ExecuteNonQuery();
                cmd2.ExecuteNonQuery();
                cmd3.ExecuteNonQuery();
                cmd4.ExecuteNonQuery();
                cmd5.ExecuteNonQuery();
                con.Close();

            }
            MySqlCommand cmd6 = new MySqlCommand("input", con);

            con.Open();
            cmd6.ExecuteNonQuery();

            con.Close();



















            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           
            timer1.Stop();
            this.Close();
        }
    }
  
}
