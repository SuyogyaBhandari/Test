﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Update
{
    public partial class Form1 : Form
    {
        MySqlConnection connection;
        MySqlDataAdapter adapter;
        DataSet ds;
        MySqlCommandBuilder cmdbl;
        public Form1()
        {
            InitializeComponent();
           

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                 connection = new MySqlConnection(@"Server=127.0.0.1;Database=app_database;Uid=root;");
                 adapter = new MySqlDataAdapter(@"SELECT item_no AS 'Item No', Items, Price FROM menutable_1 WHERE item_no IN (90,91,92,93,94)", connection);


                connection.Open();
                ds = new System.Data.DataSet();
                adapter.Fill(ds, "Update Information");
                dataGridView1.DataSource = ds.Tables[0];
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
               cmdbl = new MySqlCommandBuilder(adapter);
                adapter.Update(ds, "Update Information");
                MessageBox.Show("Information updated successfully.");

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }



    }
}
